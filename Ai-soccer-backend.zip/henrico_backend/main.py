from fastapi import FastAPI, Depends, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import httpx
import openai
import os

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

API_FOOTBALL_KEY = os.getenv("API_FOOTBALL_KEY", "your_key")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "your_openai_key")
openai.api_key = OPENAI_API_KEY

# Simple token-based Auth (stub)
USERS_DB = {"test@example.com": {"password": "test123", "favorite_teams": []}}

class AuthRequest(BaseModel):
    email: str
    password: str

@app.post("/auth/login")
def login(data: AuthRequest):
    user = USERS_DB.get(data.email)
    if not user or user["password"] != data.password:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return {"token": f"fake-jwt-token-for-{data.email}"}

# Sample data fetch
@app.get("/matches")
async def get_matches():
    headers = {"X-RapidAPI-Key": API_FOOTBALL_KEY, "X-RapidAPI-Host": "v3.football.api-sports.io"}
    url = "https://v3.football.api-sports.io/fixtures?league=39&season=2023"
    async with httpx.AsyncClient() as client:
        res = await client.get(url, headers=headers)
    return res.json()

# AI Summary
class SummaryRequest(BaseModel):
    text: str

@app.post("/ai/summary")
def summarize(data: SummaryRequest):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": f"Summarize this: {data.text}"}]
    )
    return {"summary": response.choices[0].message["content"]}

# Push Token Save
class PushToken(BaseModel):
    email: str
    token: str

push_tokens = []

@app.post("/push/register")
def register_push(data: PushToken):
    push_tokens.append(data.dict())
    return {"message": "Push token registered"}
